import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:tennis_app/components/app_colors.dart';
import 'package:tennis_app/models/login_model.dart';

// แท็บบัญชี ใช้ใน menu bar ข้างล่าง จึงไม่มี Scaffold ของตัวเอง
class AccountPage extends StatelessWidget {
  const AccountPage({super.key});

  @override
  Widget build(BuildContext context) {
    final user = Supabase.instance.client.auth.currentUser;

    return ListView(
      padding: const EdgeInsets.all(16.0),
      children: [
        const SizedBox(height: 8.0),
        const Text(
          'บัญชี',
          style: TextStyle(
            fontSize: 20.0,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 24.0),
        // ข้อมูลผู้ใช้ที่ล็อกอินอยู่
        Container(
          padding: const EdgeInsets.all(16.0),
          decoration: BoxDecoration(
            border: Border.all(color: kBorderColor),
            borderRadius: BorderRadius.circular(12.0),
          ),
          child: Row(
            children: [
              const CircleAvatar(
                radius: 28.0,
                backgroundColor: kSellerColor,
                foregroundColor: Colors.black,
                child: Icon(Icons.person, size: 32.0),
              ),
              const SizedBox(width: 16.0),
              Expanded(
                child: Column(
                  crossAxisAlignment: .start,
                  children: [
                    const Text(
                      'อีเมล',
                      style: TextStyle(color: Colors.grey),
                    ),
                    const SizedBox(height: 4.0),
                    Text(
                      user?.email ?? '-',
                      style: const TextStyle(
                        fontSize: 15.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24.0),
        // ออกจากระบบ แล้ว AuthGate จะพากลับไปหน้า login ให้เอง
        OutlinedButton.icon(
          style: OutlinedButton.styleFrom(
            foregroundColor: Colors.black,
            padding: const EdgeInsets.symmetric(vertical: 16.0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30.0),
            ),
            side: const BorderSide(color: kBorderColor),
          ),
          icon: const Icon(Icons.logout),
          label: const Text(
            'ออกจากระบบ',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          onPressed: () {
            // ล้าง username ที่จำไว้ ไม่งั้นหน้า login จะเติม email เดิมให้
            context.read<LoginModel>().username = '';
            Supabase.instance.client.auth.signOut();
          },
        ),
      ],
    );
  }
}
